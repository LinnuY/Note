$.fn.background = function(bg){
    return this.css('background', bg);
};
