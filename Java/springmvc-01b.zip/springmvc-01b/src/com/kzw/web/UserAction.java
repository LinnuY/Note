package com.kzw.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kzw.service.UserService;

/**
 * 控制器类，即MVC中的C
 * @Controller 注解在此处有特殊用途
 * */
@Controller
public class UserAction {

	@Autowired
	private UserService userService;
	
	/**
	 * 请求映射：url ==> 方法t1
	 * 返回视图名称：通过视图解析器查找真实页面
	 * */
	@RequestMapping("/user/t1")
	public String t1() {
		System.out.println("hello world");
		userService.save();
		// 返回： 视图名称 ==> 真实页面: /pages/ + 视图名称 + .jsp
		return "test1";
	}
	
	@RequestMapping("/user/t2")
	public String t2(String name, Integer age, Model model) {
		System.out.println(String.format("name=%s, age=%d", name, age));
		model.addAttribute("name", name);
		
		return "user/test2";
	}
}
