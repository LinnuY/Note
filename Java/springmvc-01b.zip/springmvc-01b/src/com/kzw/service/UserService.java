package com.kzw.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

	public void save() {
		System.out.println("保存用户信息");
	}
}
